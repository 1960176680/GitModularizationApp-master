package com.linked.erfli.library;

import com.github.mzule.activityrouter.annotation.Module;

/**
 * Created by erfli on 11/2/16.
 */
@Module("library")
public class Library {
}
