package com.linked.erfli.moduleb;

import com.github.mzule.activityrouter.annotation.Module;

/**
 * Created by erfli on 11/2/16.
 */
@Module("moduleB")
public class ModuleB {
}
