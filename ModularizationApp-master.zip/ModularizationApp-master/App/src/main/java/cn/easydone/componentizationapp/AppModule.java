package cn.easydone.componentizationapp;

import com.github.mzule.activityrouter.annotation.Module;

/**
 * Created by erfli on 11/2/16.
 */
@Module("app")
public class AppModule {
}
